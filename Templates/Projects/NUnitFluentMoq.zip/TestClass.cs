﻿namespace $safeprojectname$
{
	using NUnit.Framework;
	using FluentAssertions;
	using Moq;
	using System;
	using System.Collections.Generic;
	using System.Linq;
	using System.Text;
	using System.Threading.Tasks;

	[TestFixture]
	public class TestClass
	{
		[Test]
		public void TestMethod()
		{
			Assert.Fail();
		}
	}
}
